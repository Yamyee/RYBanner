//
//  RYPageControl.h
//  RYPageControl
//
//  Created by 全任意 on 16/11/29.
//  Copyright © 2016年 全任意. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RYPageControl : UIPageControl
@property (nonatomic,assign)CGSize dotSize;

@end
