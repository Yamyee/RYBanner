//
//  UIView_ViewControllerMethods.h
//  dxwang
//
//  Created by 吕 军 on 15/7/21.
//  Copyright (c) 2015年 happyfirst. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ViewControllerMethods)
- (UIViewController *) ownViewController;
- (id) traverseResponderChainForUIViewController;


@end
