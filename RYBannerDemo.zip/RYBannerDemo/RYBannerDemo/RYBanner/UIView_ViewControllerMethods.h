//
//  UIView_ViewControllerMethods.h
//  Banner
//
//  Created by 全任意 on 16/11/2.
//  Copyright © 2016年 全任意. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ViewControllerMethods)
- (UIViewController *) ownViewController;
- (id) traverseResponderChainForUIViewController;


@end
