//
//  ImgCell.h
//  Banner
//
//  Created by 全任意 on 16/10/19.
//  Copyright © 2016年 全任意. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RYBanner.h"
static NSString * ImgCellReuse = @"ImgCell";
@interface ImgCell : UICollectionViewCell

@property (nonatomic,strong)NSString * imgString;
@property (nonatomic,strong)UIImage * placeHolder;
@property (nonatomic,assign)RYBannerTransitionAnimation transitionAnimation;
@end
