//
//  RYPageControl.m
//  RYPageControl
//
//  Created by 全任意 on 16/11/29.
//  Copyright © 2016年 全任意. All rights reserved.
//

#import "RYPageControl.h"
static BOOL shouldAddTap = YES;
@implementation RYPageControl

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

-(void)setCurrentPage:(NSInteger)currentPage{
    
    [super setCurrentPage:currentPage];
    for (NSUInteger subviewIndex = 0; subviewIndex < [self.subviews count]; subviewIndex++) {
        UIImageView* subview = [self.subviews objectAtIndex:subviewIndex];
        CGSize size;
        if (CGSizeEqualToSize(self.dotSize, CGSizeZero)==NO) {
            size = self.dotSize;
        }else{
            size = subview.frame.size;
        }
        subview.layer.cornerRadius = size.height/2;
//        subvi
        
        [subview setFrame:CGRectMake(subview.frame.origin.x, subview.frame.origin.y,size.width,size.height)];
        if (subviewIndex == currentPage) subview.backgroundColor = self.currentPageIndicatorTintColor;
    }
    
}

-(void)onTapClick:(UITapGestureRecognizer *)tap{
    
    NSInteger i = 0;
    for (UIImageView * subView in self.subviews) {
        
        if (subView==tap.view) {
            [self setCurrentPage:i];
        }
        i++;
    }
}
@end
