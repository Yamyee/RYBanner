//
//  UIView_ViewControllerMethods.m
//  dxwang
//
//  Created by 吕 军 on 15/7/21.
//  Copyright (c) 2015年 happyfirst. All rights reserved.
//

#import "UIView_ViewControllerMethods.h"

@implementation UIView (ViewControllerMethods)

- (UIViewController *) ownViewController {
    // convenience function for casting and to "mask" the recursive function
    return (UIViewController *)[self traverseResponderChainForUIViewController];
}

- (id) traverseResponderChainForUIViewController {
    id nextResponder = [self nextResponder];
    if ([nextResponder isKindOfClass:[UIViewController class]]) {
        return nextResponder;
    } else if ([nextResponder isKindOfClass:[UIView class]]) {
        return [nextResponder traverseResponderChainForUIViewController];
    } else {
        return nil;
    }
}

@end
