//
//  UIView_ViewControllerMethods.m
//  Banner
//
//  Created by 全任意 on 16/11/2.
//  Copyright © 2016年 全任意. All rights reserved.
//

#import "UIView_ViewControllerMethods.h"

@implementation UIView (ViewControllerMethods)

- (UIViewController *) ownViewController {
    // convenience function for casting and to "mask" the recursive function
    return (UIViewController *)[self traverseResponderChainForUIViewController];
}

- (id) traverseResponderChainForUIViewController {
    id nextResponder = [self nextResponder];
    if ([nextResponder isKindOfClass:[UIViewController class]]) {
        return nextResponder;
    } else if ([nextResponder isKindOfClass:[UIView class]]) {
        return [nextResponder traverseResponderChainForUIViewController];
    } else {
        return nil;
    }
}

@end
