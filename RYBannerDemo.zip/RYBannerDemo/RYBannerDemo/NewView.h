//
//  NewView.h
//  RYBannerDemo
//
//  Created by YAMYEE on 16/11/17.
//  Copyright © 2016年 全任意. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewView : UIView

@end
