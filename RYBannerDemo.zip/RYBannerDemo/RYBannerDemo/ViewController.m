//
//  ViewController.m
//  Banner
//
//  Created by 全任意 on 16/10/19.
//  Copyright © 2016年 全任意. All rights reserved.
//

#import "ViewController.h"
#import "BannerCtrl.h"
@interface ViewController ()

@property (nonatomic,strong)UIButton * button;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self layoutUIView];
    [self eventBiding];
}



-(void)layoutUIView{
    
    self.view.backgroundColor = [UIColor whiteColor];

    _button = [UIButton buttonWithType:UIButtonTypeCustom];
    _button.frame = CGRectMake(0, 0, 80, 40);
    _button.center = self.view.center;
    [_button setTitle:@"跳转" forState:UIControlStateNormal];
    [_button setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
    [_button setBackgroundColor:[UIColor darkGrayColor]];
    [self.view addSubview:_button];

}

-(void)eventBiding{
    
    [self.button addTarget:self action:@selector(jumpTo) forControlEvents:UIControlEventTouchUpInside];
}
-(void)jumpTo{
    
    BannerCtrl * b = [[BannerCtrl alloc]init];
    [self.navigationController pushViewController:b animated:YES];
}
@end

