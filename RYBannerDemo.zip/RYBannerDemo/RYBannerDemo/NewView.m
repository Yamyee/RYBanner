//
//  NewView.m
//  RYBannerDemo
//
//  Created by YAMYEE on 16/11/17.
//  Copyright © 2016年 全任意. All rights reserved.
//

#import "NewView.h"

@interface NewView ()

@property (nonatomic,strong)UIView * view;



@end


@implementation NewView
-(void)setup{
    
    
}

-(void)layoutUIView{
    
    
}

-(void)eventBiding{
    
    
}
-(UIView *)view{
    
    if (!_view) {
        _view = [[UIView alloc]init];
    }
    return _view;
}

@end
