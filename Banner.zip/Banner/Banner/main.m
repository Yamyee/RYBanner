//
//  main.m
//  Banner
//
//  Created by 全任意 on 16/10/19.
//  Copyright © 2016年 全任意. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
