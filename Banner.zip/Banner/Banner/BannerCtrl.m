//
//  BannerCtrl.m
//  Banner
//
//  Created by 全任意 on 16/10/19.
//  Copyright © 2016年 全任意. All rights reserved.
//

#import "BannerCtrl.h"
#import "RYBanner.h"
@interface BannerCtrl ()<RYBannerDelegate>

@property (nonatomic,strong)RYBanner * banner;
@end

@implementation BannerCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setup];
    
    [self layoutUIView];
    [self eventBiding];
    
}


-(void)setup{
    self.view.backgroundColor = [UIColor whiteColor];

    
    _banner = [[RYBanner alloc]initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, 260)];
    _banner.delegate = self;
    _banner.timeInterval = 3;
    _banner.pageCtrlEnable = YES;
    _banner.scrollDirection = RYBannerScrollDirectionRight;
    _banner.pageCtrlPosition = PageCtrlPositionCenter;
    _banner.placeHolder = [UIImage imageNamed:@"hy_sy_banner"];
    [self.view addSubview:_banner];
}

-(void)layoutUIView{
    
    NSMutableArray * data = [[NSMutableArray alloc]initWithArray:@[@"http://img.zcool.cn/community/05dc4a554aed4e00000115a8220d86.jpg",@"http://4493bz.1985t.com/uploads/allimg/141204/4-141204095J8.jpg",@"http://img.pconline.com.cn/images/upload/upc/tx/wallpaper/1209/10/c1/13758581_1347257278695.jpg",@"http://imgphoto.gmw.cn/attachement/jpg/site2/20120504/f04da22dd51e110d929e38.jpg",@"http://img1.3lian.com/2015/a1/3/d/53.jpg",@"hy_sy_banner",@"http://4493bz.1985t.com/uploads/allimg/150316/4-1503161F142.jpg",@"http://image5.tuku.cn/pic/wallpaper/fengjing/langmandushiweimeisheyingkuanpingbizhi/006.jpg",@"http://img15.3lian.com/2015/f2/160/d/119.jpg"]];

    [_banner reloadImages:data];

}

-(void)eventBiding{
    
    
    

}

-(void)bannerImageSelected:(NSInteger)index{
    
    NSLog(@"selectedOne = %ld",index);

}

-(void)dealloc{
    

}
@end

